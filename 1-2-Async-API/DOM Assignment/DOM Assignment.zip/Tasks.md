Create an HTML file with a simple structure (e.g., a list of items, a form, etc.).

Write JavaScript code to manipulate the Document Object Model (DOM) in the HTML file.

Implement a functionality using an event to add a new element and change the color of an existing element.